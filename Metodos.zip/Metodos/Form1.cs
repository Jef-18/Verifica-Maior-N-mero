﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodos
{
    public partial class Form1 : Form
    {



        int VerificaMaior(int num1, int num2, int num3)
        {
            //ternário
            //return num1 > num2 ? num1 : num2;
            //return num2 > num3 ? num2 : num3;

            if (num1 > num2 )
{
                return num1;
            }

            else if (num2 > num3)
{
                return num2;
            }

            else
            {
                return num3;
            }

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (txtA.Text != "" && txtB.Text != "" && txtC.Text != "")
            {
                //declaração das variáveis
                int a, b, c;

                //entrada de dados para as variáveis
                a = Convert.ToInt32(txtA.Text);
                b = Convert.ToInt32(txtB.Text);
                c = Convert.ToInt32(txtC.Text);

                //chamando a função verificaMaior 
                //e passando os argumentos para os parâmetros num1 e num2
                // TextBox txtMaior recebe o retorno da função
                txtMaior.Text = VerificaMaior(a, b, c).ToString();

            }

            else
            {
                MessageBox.Show("Digite um valor para continuar");
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //declaração e implementação do procedimento para limpar os controles
            //o tipo de retorno é void, ou seja, não tem retorno
            void limparControles()
            {
                //limpa o conteúdos dos controles
                txtA.Clear();
                txtB.Clear();
                txtC.Clear();
                txtMaior.Clear();
                txtA.Focus();
            }

            //chama o procedimento limparControles
            limparControles();
        }

        private void txtA_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Se a tecla digitada não for número
            if (!char.IsDigit(e.KeyChar))
            {
                //Atribui True no Handled para cancelar o evento
                e.Handled = true;
            }

            //Se a tecla digitada não for número e nem backspace
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 08)
            {
                //Atribui True no Handled para cancelar o evento
                e.Handled = true;
            }
        }
    }
}
